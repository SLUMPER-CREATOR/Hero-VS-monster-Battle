﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace IslandAdventure
{
    // 🎨 Утилиты интерфейса
    public static class UI
    {
        public static void Write(string text, ConsoleColor color)
        { Console.ForegroundColor = color; Console.Write(text); Console.ResetColor(); }

        public static void WriteLine(string text, ConsoleColor color)
        { Console.ForegroundColor = color; Console.WriteLine(text); Console.ResetColor(); }

        public static void DrawSeparator(char c = '═')
        { Console.WriteLine(new string(c, 60)); }

        public static void DrawProgress(int current, int total, string label = "Прогресс")
        {
            int bars = Math.Min(30, current * 30 / Math.Max(1, total));
            // ✅ Исправлено: используем встроенный new string(char, count)
            string bar = new string('▓', bars) + new string('░', 30 - bars);
            Console.WriteLine($"   {label}: [{bar}] {current}/{total}");
        }
    }

    // 🔧 Расширение для отрисовки полосок здоровья/опыта
    public static class StatBar
    {
        public static string ToBar(this int value, int max, int length = 20, char full = '█', char empty = '░')
        {
            int filled = Math.Max(0, Math.Min(length, value * length / Math.Max(1, max)));
            // ✅ Исправлено: new string вместо кастомного Repeat
            return new string(full, filled) + new string(empty, length - filled);
        }
    }

    // 📦 Система предметов
    public enum ItemType { Heal, DamageBoost, DefenseBoost }
    public class Item
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public ItemType Type { get; set; }
        public int Value { get; set; }
        public string Description { get; set; }

        public Item(string name, int price, ItemType type, int value, string desc)
        { Name = name; Price = price; Type = type; Value = value; Description = desc; }
    }

    // 🏪 Магазин
    public static class Shop
    {
        public static List<Item> Catalog = new()
        {
            new("🧪 Зелье здоровья", 20, ItemType.Heal, 30, "Восстанавливает 30 HP"),
            new("🍖 Вяленое мясо", 35, ItemType.Heal, 60, "Восстанавливает 60 HP"),
            new("⚔️ Точильный камень", 25, ItemType.DamageBoost, 4, "+4 к урону"),
            new("💎 Кристалл силы", 50, ItemType.DamageBoost, 8, "+8 к урону"),
            new("🛡️ Кожаная накладка", 30, ItemType.DefenseBoost, 5, "Снижает входящий урон на 5")
        };

        public static void Open(Hero hero, int islandLevel)
        {
            Console.Clear();
            UI.WriteLine($"🏪 МАГАЗИН ОСТРОВА #{islandLevel}", ConsoleColor.Cyan);
            UI.DrawSeparator();

            while (true)
            {
                Console.WriteLine($"\n💰 Золото: {hero.Gold}  |  🎒 Предметов: {hero.Inventory.Count}");
                UI.DrawSeparator('─');

                for (int i = 0; i < Catalog.Count; i++)
                {
                    var catalogItem = Catalog[i]; // ✅ Переименовано
                    string typeIcon = catalogItem.Type switch
                    {
                        ItemType.Heal => "💚",
                        ItemType.DamageBoost => "🔴",
                        ItemType.DefenseBoost => "🔵",
                        _ => "⚪"
                    };
                    Console.WriteLine($"  {i + 1}. {typeIcon} {catalogItem.Name,-22} {catalogItem.Price,3}💰  │ {catalogItem.Description}");
                }
                Console.WriteLine("  0. 🔚 Выйти и продолжить приключение");
                UI.DrawSeparator('─');
                Console.Write("  Ваш выбор: ");

                if (Console.ReadKey(true).KeyChar == '0') break;
                if (!int.TryParse(Console.ReadLine()?.Trim(), out int choice) || choice < 1 || choice > Catalog.Count)
                { UI.WriteLine("  ⚠️ Неверный ввод", ConsoleColor.Yellow); Thread.Sleep(800); continue; }

                var selectedItem = Catalog[choice - 1]; // ✅ Переименовано
                if (hero.Gold >= selectedItem.Price)
                {
                    hero.Gold -= selectedItem.Price;
                    hero.Inventory.Add(new Item(selectedItem.Name, selectedItem.Price, selectedItem.Type, selectedItem.Value, selectedItem.Description));
                    UI.WriteLine($"  ✅ Куплено: {selectedItem.Name}", ConsoleColor.Green);
                }
                else UI.WriteLine("  ❌ Недостаточно золота!", ConsoleColor.Red);
                Thread.Sleep(1000);
            }
        }
    }

    // ⚔️ Базовый персонаж
    public class Character
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int MaxHealth { get; set; }
        public int Damage { get; set; }
        public int Defense { get; set; } = 0;

        public int Level { get; set; } = 1;
        public int Experience { get; set; } = 0;
        public int ExpToNext => Level * 60 + 40;
        public int StatPoints { get; set; } = 0;

        public Character(string name, int health, int damage)
        { Name = name; MaxHealth = health; Health = health; Damage = damage; }

        public void GainExperience(int amount)
        {
            Experience += amount;
            while (Experience >= ExpToNext)
            {
                Experience -= ExpToNext;
                LevelUp();
            }
        }

        private void LevelUp()
        {
            Level++;
            MaxHealth += 12;
            Health = MaxHealth;
            Damage += 3;
            StatPoints += 2;
            UI.WriteLine($"\n🌟 УРОВЕНЬ {Level}! +12 HP, +3 Урон, +2 очка характеристик", ConsoleColor.Yellow);
        }

        public virtual int CalculateDamage() => Damage;

        public virtual int TakeDamage(int rawDamage)
        {
            int actual = Math.Max(1, rawDamage - Defense);
            Health -= actual;
            return actual;
        }

        public bool IsAlive() => Health > 0;

        public void ShowStats(bool compact = false)
        {
            if (compact)
            {
                Console.Write($"[{Name} L{Level}] ");
                UI.Write($"❤️ {Health}/{MaxHealth} ", Health > MaxHealth * 0.5 ? ConsoleColor.Green : ConsoleColor.Red);
                Console.Write($"⚔️ {Damage} ");
                if (Defense > 0) Console.Write($"🛡️ {Defense} ");
                if (StatPoints > 0) UI.Write($"📊 +{StatPoints} ", ConsoleColor.Cyan);
                Console.WriteLine();
            }
            else
            {
                UI.WriteLine($"\n👤 {Name.ToUpper()} | Уровень {Level}", ConsoleColor.Cyan);
                Console.WriteLine($"   ❤️ Здоровье:  {Health.ToBar(MaxHealth)} {Health}/{MaxHealth}");
                Console.WriteLine($"   ⚔️ Урон:      {Damage}  |  🛡️ Защита: {Defense}");
                Console.WriteLine($"   📈 Опыт:      {Experience.ToBar(ExpToNext)} {Experience}/{ExpToNext}");
                if (StatPoints > 0) UI.WriteLine($"   📊 Очки характеристик: {StatPoints} (нажмите S для распределения)", ConsoleColor.Cyan);
            }
        }

        public virtual void AllocateStats()
        {
            if (StatPoints <= 0) return;
            Console.WriteLine("\n📊 РАСПРЕДЕЛЕНИЕ ОЧКОВ");
            Console.WriteLine("  1. 💪 Сила:     +3 урон за очко");
            Console.WriteLine("  2. 🛡️ Выносливость: +15 макс. HP за очко");
            Console.WriteLine("  3. 🧠 Ловкость:  +2 защита за очко");
            Console.WriteLine("  0. Выйти");

            while (StatPoints > 0)
            {
                Console.Write($"\n  Очков осталось: {StatPoints} → Выбор: ");
                var key = Console.ReadKey(true).KeyChar;
                Console.WriteLine(key);

                if (key == '0') break;
                if (key == '1') { Damage += 3; StatPoints--; UI.WriteLine("  ✅ +3 Урон", ConsoleColor.Green); }
                else if (key == '2') { MaxHealth += 15; Health += 15; StatPoints--; UI.WriteLine("  ✅ +15 HP", ConsoleColor.Green); }
                else if (key == '3') { Defense += 2; StatPoints--; UI.WriteLine("  ✅ +2 Защита", ConsoleColor.Green); }
                else UI.WriteLine("  ⚠️ Неверная клавиша", ConsoleColor.Yellow);
            }
        }
    }

    // 🦸 Герой
    public class Hero : Character
    {
        public int Gold { get; set; }
        public List<Item> Inventory { get; set; } = new();
        public bool AutoBattle { get; set; } = false;

        public Hero(string name, int health, int damage, int gold) : base(name, health, damage)
        { Gold = gold; }

        public void UseItem(int index)
        {
            if (index < 0 || index >= Inventory.Count) return;
            var usedItem = Inventory[index]; // ✅ Переименовано

            switch (usedItem.Type)
            {
                case ItemType.Heal:
                    int oldHp = Health;
                    Health = Math.Min(Health + usedItem.Value, MaxHealth);
                    UI.WriteLine($"  💚 {usedItem.Name}: +{Health - oldHp} HP ({Health}/{MaxHealth})", ConsoleColor.Green);
                    break;
                case ItemType.DamageBoost:
                    Damage += usedItem.Value;
                    UI.WriteLine($"  🔴 {usedItem.Name}: +{usedItem.Value} урона (текущий: {Damage})", ConsoleColor.Red);
                    break;
                case ItemType.DefenseBoost:
                    Defense += usedItem.Value;
                    UI.WriteLine($"  🔵 {usedItem.Name}: +{usedItem.Value} защиты (текущая: {Defense})", ConsoleColor.Blue);
                    break;
            }
            Inventory.RemoveAt(index);
        }

        public void ShowInventory()
        {
            Console.WriteLine("\n🎒 ИНВЕНТАРЬ:");
            if (Inventory.Count == 0) { UI.WriteLine("  (пусто)", ConsoleColor.Gray); return; }

            for (int i = 0; i < Inventory.Count; i++)
            {
                var invItem = Inventory[i]; // ✅ Переименовано
                string icon = invItem.Type switch { ItemType.Heal => "💚", ItemType.DamageBoost => "🔴", _ => "🔵" };
                Console.WriteLine($"  {i + 1}. {icon} {invItem.Name}  │  {invItem.Description}");
            }
            Console.WriteLine("  0. Отмена");
        }

        public override void AllocateStats()
        {
            base.AllocateStats();
            if (Health > MaxHealth) Health = MaxHealth;
        }
    }

    // 👹 Монстр
    public class Monster : Character
    {
        public int GoldReward { get; set; }
        public int XpReward { get; set; }
        public bool IsBoss { get; set; } = false;
        private static readonly Random rng = new();

        public Monster(string name, int health, int damage, int level, bool isBoss = false) : base(name, health, damage)
        {
            Level = level;
            IsBoss = isBoss;
            int multiplier = isBoss ? 3 : 1;
            GoldReward = (level * 12 + 15) * multiplier;
            XpReward = (level * 20 + 30) * multiplier;
            if (isBoss) { MaxHealth = (int)(MaxHealth * 1.5); Health = MaxHealth; Damage = (int)(Damage * 1.3); }
        }

        public override int CalculateDamage() => Damage + rng.Next(-2, 3);

        public override int TakeDamage(int rawDamage)
        {
            int actual = IsBoss ? Math.Max(1, rawDamage - 2) : base.TakeDamage(rawDamage);
            Health -= actual;
            return actual;
        }
    }

    // 🗺️ Система островов
    public static class IslandSystem
    {
        public static int TotalIslands = 5;
        private static readonly Random rng = new();

        public static List<Monster> GetMonstersForIsland(int islandLevel)
        {
            var monsters = new List<Monster>();
            int count = rng.Next(2, 5);
            string[] names = { "Дикий Кабан", "Лесной Гоблин", "Ядовитый Паук", "Разбойник", "Теневой Волк" };

            for (int i = 0; i < count; i++)
            {
                var name = names[rng.Next(names.Length)];
                int hp = 40 + islandLevel * 15 + rng.Next(-10, 11);
                int dmg = 8 + islandLevel * 3 + rng.Next(-2, 3);
                monsters.Add(new Monster(name, hp, dmg, islandLevel + rng.Next(0, 2)));
            }

            if (islandLevel == TotalIslands)
            {
                monsters.Add(new Monster("👹 ВЛАСТЕЛИН ОСТРОВА", 150 + islandLevel * 30, 18 + islandLevel * 4, islandLevel + 2, true));
            }

            return monsters;
        }

        public static string GetIslandName(int level) => level switch
        {
            1 => "🌴 Пляж Новичка",
            2 => "🌲 Тенистый Лес",
            3 => "⛰️ Скалистые Холмы",
            4 => "🌋 Огненная Пещера",
            5 => "🏰 Замок Тьмы",
            _ => $"🗺️ Неизведанная Земля #{level}"
        };
    }

    class Program
    {
        static Hero hero;
        static readonly Random rng = new();

        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.CursorVisible = false;

            hero = new Hero("Артур", 100, 12, 50);

            ShowTitle();
            ShowTutorial();

            for (int island = 1; island <= IslandSystem.TotalIslands; island++)
            {
                if (!PlayIsland(island)) break;
                if (island < IslandSystem.TotalIslands)
                {
                    UI.WriteLine("\n🌅 Переход к следующему острову...", ConsoleColor.Cyan);
                    Thread.Sleep(1500);
                    Shop.Open(hero, island + 1);
                }
            }

            ShowEnding();
            Console.ReadKey();
        }

        static void ShowTitle()
        {
            Console.Clear();
            UI.WriteLine("\n   ⚔️  ISLAND ADVENTURE  ⚔️", ConsoleColor.Yellow);
            UI.WriteLine("   Приключение Героя", ConsoleColor.Cyan);
            UI.DrawSeparator();
            Console.WriteLine("   Управление: Цифры/Буквы + Enter или просто клавиша");
            Console.WriteLine("   A/I/S/R/T = Атака/Инвентарь/Статы/Отдых/Авто-бой");
            UI.DrawSeparator();
            Console.Write("\n   Нажмите любую клавишу...");
            Console.ReadKey(true);
        }

        static void ShowTutorial()
        {
            Console.Clear();
            UI.WriteLine("📜 КРАТКИЙ ПУТЕВОДИТЕЛЬ", ConsoleColor.Yellow);
            Console.WriteLine("\n  🎯 Цель: Победить всех монстров на 5 островах");
            Console.WriteLine("  💰 Золото: Тратьте в магазине на зелья и улучшения");
            Console.WriteLine("  📈 Опыт: Получайте за победы, повышайте уровень");
            UI.DrawSeparator();
            Console.Write("\n  Нажмите Enter для старта...");
            Console.ReadKey();
        }

        static bool PlayIsland(int islandLevel)
        {
            var monsters = IslandSystem.GetMonstersForIsland(islandLevel);
            string islandName = IslandSystem.GetIslandName(islandLevel);

            Console.Clear();
            UI.WriteLine($"\n🏝️ ОСТРОВ #{islandLevel}: {islandName}", ConsoleColor.Cyan);
            UI.DrawProgress(islandLevel, IslandSystem.TotalIslands, "Прогресс приключения");
            Console.WriteLine($"\n  Врагов на острове: {monsters.Count}");
            if (monsters.Any(m => m.IsBoss)) UI.WriteLine("  ⚠️ ВНИМАНИЕ: На этом острове есть БОСС!", ConsoleColor.Red);
            UI.DrawSeparator();
            Console.Write("  [Enter] Начать  |  [M] Магазин  |  [Q] Статы: ");

            var startKey = Console.ReadKey(true).Key;
            if (startKey == ConsoleKey.M) { Shop.Open(hero, islandLevel); }
            if (startKey == ConsoleKey.Q) { hero.ShowStats(); Console.ReadKey(true); }

            for (int i = 0; i < monsters.Count && hero.IsAlive(); i++)
            {
                var monster = monsters[i];
                Console.Clear();

                UI.WriteLine($"\n⚔️ БОЙ {i + 1}/{monsters.Count}", ConsoleColor.Yellow);
                Console.WriteLine($"  🏝️ Остров #{islandLevel}: {islandName}");
                UI.DrawSeparator();

                hero.ShowStats(compact: true);
                monster.ShowStats(compact: true);
                if (monster.IsBoss) UI.WriteLine("  👹 Это БОСС! Будьте осторожны!", ConsoleColor.Red);
                UI.DrawSeparator();

                while (hero.IsAlive() && monster.IsAlive())
                {
                    if (hero.AutoBattle || HandleHeroTurn(monster))
                    {
                        if (!monster.IsAlive()) break;
                        Thread.Sleep(400);
                        int actual = hero.TakeDamage(monster.CalculateDamage());
                        UI.Write($"\n  🔻 {monster.Name} атакует: ", ConsoleColor.Red);
                        UI.WriteLine($"-{actual} HP", ConsoleColor.Gray);
                        if (!hero.IsAlive()) break;
                    }
                    Thread.Sleep(300);
                }

                ShowBattleResults(monster);
                if (!hero.IsAlive()) return false;

                if (i > 0 && i % 2 == 0 && hero.Health < hero.MaxHealth * 0.7)
                {
                    Console.Write("\n  💤 Отдохнуть? [Y/N]: ");
                    if (Console.ReadKey(true).Key == ConsoleKey.Y)
                    {
                        int heal = hero.MaxHealth / 4;
                        hero.Health = Math.Min(hero.Health + heal, hero.MaxHealth);
                        UI.WriteLine($"\n  💚 Отдых восстановил {heal} HP", ConsoleColor.Green);
                        Thread.Sleep(1000);
                    }
                }
            }
            return hero.IsAlive();
        }

        static bool HandleHeroTurn(Monster monster)
        {
            Console.WriteLine("\n  🎮 Ваши действия:");
            Console.WriteLine("  [A] Атака  [I] Инвентарь  [S] Статы  [R] Отдых  [T] Авто-бой");
            Console.Write("  Выбор: ");

            var key = Console.ReadKey(true).KeyChar.ToString().ToUpper();
            Console.WriteLine(key);

            if (Console.KeyAvailable && Console.ReadKey(true).Key == ConsoleKey.Escape)
            { ShowPauseMenu(); return false; }

            switch (key)
            {
                case "A":
                case "1":
                    int actual = monster.TakeDamage(hero.CalculateDamage());
                    UI.Write($"  ⚔️ Вы атакуете: ", ConsoleColor.Green);
                    UI.WriteLine($"-{actual} HP", ConsoleColor.Red);
                    return true;
                case "I":
                case "2":
                    hero.ShowInventory();
                    Console.Write("  Номер предмета: ");
                    if (int.TryParse(Console.ReadLine()?.Trim(), out int idx) && idx > 0 && idx <= hero.Inventory.Count)
                        hero.UseItem(idx - 1);
                    return false;
                case "S":
                case "3":
                    hero.AllocateStats();
                    return false;
                case "R":
                case "4":
                    int heal = Math.Min(20, hero.MaxHealth - hero.Health);
                    if (heal > 0) { hero.Health += heal; UI.WriteLine($"  💚 Отдых: +{heal} HP", ConsoleColor.Green); }
                    else UI.WriteLine("  💤 Вы полны сил!", ConsoleColor.Gray);
                    return false;
                case "T":
                    hero.AutoBattle = !hero.AutoBattle;
                    UI.WriteLine($"  ⚡ Авто-бой: {(hero.AutoBattle ? "ВКЛ" : "ВЫКЛ")}", ConsoleColor.Cyan);
                    return false;
                default:
                    UI.WriteLine("  ⚠️ Неверная команда", ConsoleColor.Yellow);
                    return false;
            }
        }

        static void ShowBattleResults(Monster monster)
        {
            Console.Clear();
            UI.DrawSeparator();
            if (hero.IsAlive())
            {
                UI.WriteLine($"  🏆 ПОБЕДА! {monster.Name} повержен", ConsoleColor.Green);
                UI.WriteLine($"  💰 Награда: +{monster.GoldReward} золота", ConsoleColor.Yellow);
                UI.WriteLine($"  📈 Опыт: +{monster.XpReward} XP", ConsoleColor.Cyan);

                hero.Gold += monster.GoldReward;
                hero.GainExperience(monster.XpReward);

                if (rng.Next(100) < 30)
                {
                    var lootItem = Shop.Catalog[rng.Next(Shop.Catalog.Count)]; // ✅ Переименовано
                    hero.Inventory.Add(new Item(lootItem.Name, lootItem.Price, lootItem.Type, lootItem.Value, lootItem.Description));
                    UI.WriteLine($"  🎁 Вы нашли: {lootItem.Name}!", ConsoleColor.Magenta);
                }
                if (monster.IsBoss)
                {
                    UI.WriteLine("\n  👑 ОСТРОВ ПРОЙДЕН!", ConsoleColor.Yellow);
                    Thread.Sleep(2000);
                }
            }
            else UI.WriteLine($"  💀 ПОРАЖЕНИЕ", ConsoleColor.Red);

            UI.DrawSeparator();
            hero.ShowStats(compact: true);
            Console.WriteLine("\n  [Enter] Продолжить...");
            Console.ReadKey();
        }

        static void ShowPauseMenu()
        {
            Console.Clear();
            UI.WriteLine("\n⏸️ ПАУЗА", ConsoleColor.Cyan);
            UI.DrawSeparator();
            Console.WriteLine("  [C] Продолжить  [Q] Статистика  [X] Сдаться");
            UI.DrawSeparator();
            Console.Write("  Выбор: ");
            var key = Console.ReadKey(true).Key;
            if (key == ConsoleKey.Q) { hero.ShowStats(); Console.ReadKey(true); ShowPauseMenu(); }
            if (key == ConsoleKey.X) hero.Health = 0;
        }

        static void ShowEnding()
        {
            Console.Clear();
            UI.DrawSeparator('★');
            if (hero.IsAlive())
            {
                UI.WriteLine("\n  🎉 ПОЗДРАВЛЯЕМ! ВЫ ПРОШЛИ ВСЕ ОСТРОВА!", ConsoleColor.Yellow);
                UI.WriteLine($"  🦸 {hero.Name} достиг уровня {hero.Level}!", ConsoleColor.Cyan);
                UI.WriteLine($"  💰 Итоговое золото: {hero.Gold} | 🎒 Предметов: {hero.Inventory.Count}", ConsoleColor.Magenta);
                UI.WriteLine("\n  🏆 Вы настоящий Герой!", ConsoleColor.Green);
            }
            else UI.WriteLine("\n  💀 Герой пал в бою... Но легенда живёт!", ConsoleColor.Red);
            UI.DrawSeparator('★');
            Console.WriteLine("\n  [Enter] Выход");
        }
    }
}